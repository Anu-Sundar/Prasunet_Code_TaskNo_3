let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let timerInterval;

function startTimer() {
    clearInterval(timerInterval);
    timerInterval = setInterval(updateTime, 10);
    document.getElementById('start-timer').disabled = true;
    document.getElementById('pause-timer').disabled = false;
}

function pauseTimer() {
    clearInterval(timerInterval);
    document.getElementById('start-timer').disabled = false;
    document.getElementById('pause-timer').disabled = true;
}

function resetTimer() {
    clearInterval(timerInterval);
    minutes = 0;
    seconds = 0;
    milliseconds = 0;
    updateDisplay();
    document.getElementById('start-timer').disabled = false;
    document.getElementById('pause-timer').disabled = true;
}

function updateTime() {
    milliseconds += 10;
    if (milliseconds >= 1000) {
        milliseconds = 0;
        seconds++;
    }
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
    }
    updateDisplay();
}

function updateDisplay() {
    document.getElementById('timer-display').textContent = 
        `${formatTime(minutes)}:${formatTime(seconds)}:${formatMilliseconds(milliseconds)}`;
}

function formatTime(time) {
    return time < 10 ? '0' + time : time;
}

function formatMilliseconds(time) {
    return time < 100 ? '0' + (time < 10 ? '0' + time : time) : time;
}

// Disable pause button initially
document.getElementById('pause-timer').disabled = true;
